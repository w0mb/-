#include <iostream>
#include <string>
#include <cmath>

typedef long double Decimal;

Decimal fun(Decimal x) {
    return pow(x, 2) - 6 * x;
}

int main() {
    Decimal epsilon;
    std::cout << "Введите необходимую точность (кол-во знаков после запятой): ";
    std::cin >> epsilon;

    Decimal a, b;
    std::cout << "Введите a и b: ";
    std::cin >> a >> b;

    while (true) {
        if ((b - a) / 2 < epsilon) {
            std::cout << (b + a) / 2 << std::endl;
            break;
        }
        Decimal l1 = a + 0.382 * (b - a);
        Decimal l2 = a + 0.618 * (b - a);
        if (fun(l1) > fun(l2)) {
            a = l1;
        } else {
            b = l2;
        }
    }

    return 0;
}
