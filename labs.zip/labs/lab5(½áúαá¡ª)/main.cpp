#include <iostream>
#include <cmath>
#include <vector>

using namespace std;

double factorial(int x) {
    double fact = 1;
    for (int i = 2; i <= x; ++i) {
        fact *= i;
    }
    return fact;
}

double lagrange(vector<double>& x_arr, vector<double>& y_arr, int n, double x) {
    double result = 0.0;
    for (int i = 0; i <= n; ++i) {
        double q = 1.0;
        for (int j = 0; j <= n; ++j) {
            if (i != j) {
                q *= (x - x_arr[j]) / (x_arr[i] - x_arr[j]);
            }
        }
        result += y_arr[i] * q;
    }
    return result;
}

double eitken(vector<double>& x_arr, vector<double>& y_arr, int n, double x) {
    vector<vector<double>> p(n + 1, vector<double>(n + 1, 0.0));
    for (int i = 0; i <= n; ++i) {
        p[0][i] = y_arr[i];
    }
    for (int i = 1; i <= n; ++i) {
        for (int j = 0; j <= n - i; ++j) {
            p[i][j] = (p[i - 1][j] * (x - x_arr[j + i]) - p[i - 1][j + 1] * (x - x_arr[j])) / (x_arr[j] - x_arr[j + i]);
        }
    }
    return p[n][0];
}

double newton_1(vector<double>& x_arr, vector<vector<double>>& del_y, int n, double x) {
    double q = (x - x_arr[0]) / (x_arr[1] - x_arr[0]);
    double qq = 1.0;
    double result = 0.0;
    for (int i = 0; i <= n; ++i) {
        result += (del_y[i][0] / factorial(i)) * qq;
        qq *= (q - i);
    }
    return result;
}

double newton_2(vector<double>& x_arr, vector<vector<double>>& del_y, int n, double x) {
    double q = (x - x_arr[n]) / (x_arr[1] - x_arr[0]);
    double qq = 1.0;
    double result = 0.0;
    for (int i = 0; i <= n; ++i) {
        result += (del_y[i][n - i] / factorial(i)) * qq;
        qq *= (q + i);
    }
    return result;
}

int main() {
    vector<double> x_arr = {1.0, 1.2, 1.4, 1.6, 1.8, 2.0, 2.2, 2.4};
    vector<double> y_arr;
    for (double x : x_arr) {
        y_arr.push_back(sqrt(x));
    }
    
    int n = 7;
    double x = 2.5;

    // Лагранж
    cout << "lagra: " << lagrange(x_arr, y_arr, n, x) << endl;

    // Эйткен
    cout << "eiteken: " << eitken(x_arr, y_arr, n, x) << endl;

    // Ньютон #1
    vector<vector<double>> del_y(n + 1, vector<double>());
    for (int i = 0; i <= n; ++i) {
        del_y[i].push_back(y_arr[i]);
    }
    for (int i = 1; i <= n; ++i) {
        for (int j = 0; j <= n - i; ++j) {
            del_y[j].push_back(del_y[j + 1][i - 1] - del_y[j][i - 1]);
        }
    }
    cout << "nuton #1: " << newton_1(x_arr, del_y, n, x) << endl;

    // Ньютон #2
    cout << "nuton #2: " << newton_2(x_arr, del_y, n, x) << endl;

    return 0;
}
